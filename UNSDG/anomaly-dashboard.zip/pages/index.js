import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md p-4 flex space-x-4">
        <button className="p-2 bg-gray-200 rounded">Menu 1</button>
        <button className="p-2 bg-gray-200 rounded">Menu 2</button>
        <Link href="/anomaly">
          <button className="p-2 bg-blue-500 text-white rounded">Anomaly</button>
        </Link>
      </nav>
    </div>
  );
}